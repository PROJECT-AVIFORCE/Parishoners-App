package com.example.parishoners;

public interface SelectListener {
    void onitemclick(FeaturedHelperClass featuredHelperClass);
}
